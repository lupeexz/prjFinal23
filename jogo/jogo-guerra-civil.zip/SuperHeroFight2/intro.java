import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class intro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class intro extends World
{
    public int temp = 50;
    public int temp1 = 50;
    public int temp2 = 50;

    /**
     * Constructor for objects of class intro.
     * 
     */
    public intro()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(300, 308, 1); 
    }
    public void act(){
    temp--;

    if(Greenfoot.isKeyDown("enter") && (temp < 1)){
        setBackground(new GreenfootImage("dialogocapamerica.png"));
        temp1--;
    }

    if (Greenfoot.isKeyDown("enter") && (temp1 < 1)){
        setBackground(new GreenfootImage("dialogohomemdeferro.png"));
        temp2--;
    }


    if (Greenfoot.isKeyDown("enter") && (temp2 < 1)){
        meuMundo world = new meuMundo();
        Greenfoot.setWorld(world);
    }
}
}
