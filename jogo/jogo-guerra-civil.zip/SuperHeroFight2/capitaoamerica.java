import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class capitaoamerica here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */


public class capitaoamerica extends Actor
{
    GifImage myGif = new GifImage("capinicial.gif");
    GifImage myGif1 = new GifImage("capandando1.gif");
    GifImage myGif2 = new GifImage("capandando2.gif");
    GifImage myGif3 = new GifImage("capabaixado1.gif");
    GifImage myGif4 = new GifImage("capataque.gif");
    GifImage myGif5 = new GifImage("capespecial.gif");

    private GreenfootSound ataque = new GreenfootSound("ataque.mp3");
    
    private int speed = 3;
    private int jumpStrength = 15;
    private int combo = 0;
    private int ySpeed = 0;
    private boolean agachar = false;
    private boolean especial = false;
    private boolean bateu = false;
    private boolean teste = false;
    private int vida = 10;
    /**
     * Act - do whatever the capitaoamerica wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setImage(myGif.getCurrentImage());
        movimento();
        Gravidade();
        chao();
        dano();
    }
    public void dano(){
        if(!Greenfoot.isKeyDown("f")){
            bateu = false;
        }
        if(Greenfoot.isKeyDown("f") && isTouching(homemdeferro.class) && !bateu){
            if(!especial){
                vida--;
            }
            if(especial){
                vida-=10000;
            }
            bateu = true;
            combo++;
            if(combo == 3) {
                especial = true;
                combo = 0;
            }
            if(vida <= 0){
                removeTouching(homemdeferro.class);
                vitoriacapamerica world = new vitoriacapamerica();
                Greenfoot.setWorld(world);
            }
        }
    }
    public void movimento(){
        if (!Greenfoot.isKeyDown("s") && agachar) {
            this.setLocation(this.getX(), this.getY()-60);
            agachar = false;
        }
        
        if (Greenfoot.isKeyDown("w") && chao()) {
            ySpeed = -jumpStrength;
    }
        else if (Greenfoot.isKeyDown("s")){
        setImage(myGif3.getCurrentImage());
        agachar = true;
    }
        else if (Greenfoot.isKeyDown("a")){
        this.setLocation(this.getX() - speed, this.getY());
        setImage(myGif2.getCurrentImage());
    }
        else if (Greenfoot.isKeyDown("d")){
        this.setLocation(this.getX() + speed, this.getY());
        setImage(myGif1.getCurrentImage());
    }
        else if (Greenfoot.isKeyDown("f") && !especial){
        this.setLocation(this.getX() + speed, this.getY());
        setImage(myGif4.getCurrentImage());
        ataque.play();
        
    }   else if (Greenfoot.isKeyDown("f") && especial){
        this.setLocation(this.getX() + speed, this.getY());
        setImage(myGif5.getCurrentImage());
        
        ataque.play();
        teste = true;
    }   
    if (!Greenfoot.isKeyDown("f") && teste && especial){
        ataque.play();
        especial = false;
        teste = false;
    }
        

        setLocation(getX(), getY() + ySpeed);
}

    private void Gravidade()
    {
        if (!chao()) {
            ySpeed = ySpeed + 1;
        } else {
            ySpeed = 0;
        }
    }

    private boolean chao()
    {
        int alturaDoChao = 220;
        return getY() >= alturaDoChao;
    }
}