import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class homemdeferro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class homemdeferro extends Actor
{
    GifImage myGif = new GifImage("homemdeferroinicial.gif");
    GifImage myGif1 = new GifImage("homemdeferroandando1.gif");
    GifImage myGif2 = new GifImage("homemdeferroandando2.gif");
    GifImage myGif3 = new GifImage("homemdeferroataque.gif");
    GifImage myGif4 = new GifImage("homemdeferroagachado.gif");
    GifImage myGif5 = new GifImage("homemdeferroespecial.gif");
    
    private int speed = 3;
    private int jumpStrength = 15;
    private int combo = 0;
    private int ySpeed = 0;
    private boolean agachar = false;
    private boolean especial = false;
    private boolean bateu = false;
    private boolean teste = false;
    private int vida = 10;
    /**
     * Act - do whatever the homemdeferro wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        setImage(myGif.getCurrentImage());
        movimento();
        Gravidade();
        chao();
        dano();
    }
    public void dano(){
        if(!Greenfoot.isKeyDown("space")){
            bateu = false;
        }
        if(Greenfoot.isKeyDown("space") && isTouching(capitaoamerica.class) && !bateu){
            if(!especial){
                vida--;
            }
            if(especial){
                vida-=10000;
            }
            bateu = true;
            combo++;
            if(combo == 3) {
                especial = true;
                combo = 0;
            }
            if(vida <= 0){
                removeTouching(capitaoamerica.class);
                vitoriahomemdeferro world = new vitoriahomemdeferro();
                Greenfoot.setWorld(world);
            }
        }
    }
    public void movimento(){
        if (!Greenfoot.isKeyDown("down") && agachar) {
            this.setLocation(this.getX(), this.getY()-60);
            agachar = false;
        }
        
        if (Greenfoot.isKeyDown("up") && chao()) {
            ySpeed = -jumpStrength;
    }
        else if (Greenfoot.isKeyDown("down")){
        setImage(myGif4.getCurrentImage());
        agachar = true;
    }
        else if (Greenfoot.isKeyDown("left")){
        this.setLocation(this.getX() - speed, this.getY());
        setImage(myGif2.getCurrentImage());
    }
        else if (Greenfoot.isKeyDown("right")){
        this.setLocation(this.getX() + speed, this.getY());
        setImage(myGif1.getCurrentImage());
    }
        else if (Greenfoot.isKeyDown("space") && !especial){
        this.setLocation(this.getX() - speed, this.getY());
        setImage(myGif3.getCurrentImage());
        
    }   else if (Greenfoot.isKeyDown("space") && especial){
        this.setLocation(this.getX() - speed, this.getY());
        setImage(myGif5.getCurrentImage());
        teste = true;
    }   
    if (!Greenfoot.isKeyDown("space") && teste && especial){
        especial = false;
        teste = false;
    }
        setLocation(getX(), getY() + ySpeed);
}

    private void Gravidade()
    {
        if (!chao()) {
            ySpeed = ySpeed + 1;
        } else {
            ySpeed = 0;
        }
    }

    private boolean chao()
    {
        int alturaDoChao = 220;
        return getY() >= alturaDoChao;
    }
}