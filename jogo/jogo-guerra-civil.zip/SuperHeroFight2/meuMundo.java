import greenfoot.*; 

public class meuMundo extends World {

    private GreenfootSound bgMusic = new GreenfootSound("musica.mp3");
    
    public void act() {
        bgMusic.playLoop();
    }
 
    public void stopped() {
        bgMusic.pause();
    }
    
    public meuMundo() {    
        super(300, 308, 1); 
        prepare();
    }

    private void prepare() {
        homemdeferro homemdeferro = new homemdeferro();
        addObject(homemdeferro, 242, 238);
        capitaoamerica capitaoamerica = new capitaoamerica();
        addObject(capitaoamerica, 65, 231);
    }

    private void verificarVitoria() {
        if (getObjects(homemdeferro.class).isEmpty()) {
        setBackground(new GreenfootImage("vitoriacapamerica.png"));
        }

        if (getObjects(capitaoamerica.class).isEmpty()) {
        setBackground(new GreenfootImage("vitoriahomemdeferro.png"));
        }
    }
}
