import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class vitoriacapamerica here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class vitoriacapamerica extends World
{

    /**
     * Constructor for objects of class vitoriacapamerica.
     * 
     */
    public vitoriacapamerica()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(300, 308, 1);
    }
    
    public void act(){
    if (Greenfoot.isKeyDown("enter")){
        intro world = new intro();
        Greenfoot.setWorld(world);
    }
}}
